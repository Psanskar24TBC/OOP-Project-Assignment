package week3;
import java.util.Scanner;
import java.util.Random;

public class Rockpaperscissor {
	// ****************************************************************
//  Rock.java
//
//  Play Rock, Paper, Scissors with the user
//         
//****************************************************************
   public static void main(String[] args) {
       String personPlay;    // User's play -- "R", "P", or "S"
       String computerPlay;  // Computer's play -- "R", "P", or "S"
       int computerInt;      // Randomly generated number for computer's play

       Scanner scan = new Scanner(System.in);
       Random generator = new Random();

       // Get player's play
       System.out.print("Enter your play (R, P, or S): ");
       personPlay = scan.next().toUpperCase(); // Convert to uppercase for consistency

       // Generate computer's play (0, 1, 2)
       computerInt = generator.nextInt(3); // Generates 0, 1, or 2

       // Translate computer's randomly generated play to a string
       switch (computerInt) {
           case 0 -> computerPlay = "R"; // Rock
           case 1 -> computerPlay = "P"; // Paper
           default -> computerPlay = "S"; // Scissors
       }

       // Print computer's play
       System.out.println("Computer played: " + computerPlay);

       // Determine the winner using nested ifs
       if (personPlay.equals(computerPlay)) {
           System.out.println("It's a tie!");
       } else if (personPlay.equals("R")) {
           if (computerPlay.equals("S")) {
               System.out.println("Rock crushes Scissors. You win!!");
           } else {
               System.out.println("Paper covers Rock. Computer wins!");
           }
       } else if (personPlay.equals("P")) {
           if (computerPlay.equals("R")) {
               System.out.println("Paper covers Rock. You win!!");
           } else {
               System.out.println("Scissors cut Paper. Computer wins!");
           }
       } else if (personPlay.equals("S")) {
           if (computerPlay.equals("P")) {
               System.out.println("Scissors cut Paper. You win!!");
           } else {
               System.out.println("Rock crushes Scissors. Computer wins!");
           }
       } else {
           System.out.println("Invalid input! Please enter R, P, or S.");
       }

       scan.close(); // Close the scanner
   }
}


