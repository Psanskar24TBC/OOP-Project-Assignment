package week3;
import java.util.Scanner;

public class Stringreverser {
	

	    public static void main(String[] args) {
	        Scanner scan = new Scanner(System.in);

	        // Prompt user for input
	        System.out.print("Enter a sentence: ");
	        String sentence = scan.nextLine();

	        // Process and reverse words
	        String reversedSentence = reverseEachWord(sentence);

	        // Output the result
	        System.out.println("Reversed sentence: " + reversedSentence);

	        scan.close();
	    }

	    public static String reverseEachWord(String sentence) {
	        String[] words = sentence.split(" "); // Split sentence into words
	        StringBuilder result = new StringBuilder();

	        for (String word : words) {
	            StringBuilder reversedWord = new StringBuilder(word).reverse(); // Reverse each word
	            result.append(reversedWord).append(" "); // Append to result with space
	        }

	        return result.toString().trim(); // Convert to string and remove trailing space
	    }
	}




