package week3;
import java.util.HashMap;
import java.util.Map;

public class Puntuationmarks {
	
	
	    public static void main(String[] args) {
	        // Given string
	        String text = "Mary had a little lamb, her fleece was as white as snow, and everywhere Mary went, the lamb was sure to go. -that was a nice poem- the end. ";

	        // Define punctuation characters to count
	        String punctuationMarks = ".,-";

	        // Create a HashMap to store punctuation counts
	        Map<Character, Integer> punctuationCount = new HashMap<>();

	        // Initialize counts to 0
	        for (char c : punctuationMarks.toCharArray()) {
	            punctuationCount.put(c, 0);
	        }

	        // Count punctuation marks in the string
	        for (char ch : text.toCharArray()) {
	            if (punctuationCount.containsKey(ch)) {
	                punctuationCount.put(ch, punctuationCount.get(ch) + 1);
	            }
	        }

	        // Print results in a table format
	        System.out.println("Punctuation Count:");
	        System.out.println("-------------------");
	        System.out.println("Symbol | Count");
	        System.out.println("-------------------");
	        for (Map.Entry<Character, Integer> entry : punctuationCount.entrySet()) {
	            System.out.printf("   %c    |   %d\n", entry.getKey(), entry.getValue());
	        }
	        System.out.println("-------------------");
	    }
	}



