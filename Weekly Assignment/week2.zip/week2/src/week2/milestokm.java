package week2;
import java.util.Scanner;

public class milestokm {
	

	    public static void main(String[] args) {
	        final double CONVERSION_FACTOR = 1.60935; // 1 mile = 1.60935 km
	        double miles, kilometers;
	        Scanner scan = new Scanner(System.in);

	        // Get miles input from the user
	        System.out.print("Enter the distance in miles: ");
	        miles = scan.nextDouble();

	        // Convert miles to kilometers
	        kilometers = miles * CONVERSION_FACTOR;

	        // Display the result
	        System.out.println(miles + " miles is equal to " + kilometers + " kilometers.");

	        scan.close(); // Close the scanner
	    }
	}

