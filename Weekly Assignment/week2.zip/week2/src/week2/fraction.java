package week2;
import java.util.Scanner;

public class fraction {
	

	
	    public static void main(String[] args) {
	        int numerator, denominator;
	        double decimalEquivalent;
	        Scanner scan = new Scanner(System.in);

	        // Prompt the user for input
	        System.out.print("Enter the numerator: ");
	        numerator = scan.nextInt();

	        System.out.print("Enter the denominator: ");
	        denominator = scan.nextInt();

	        // Check if denominator is zero to avoid division by zero
	        if (denominator == 0) {
	            System.out.println("Error: Division by zero is not allowed.");
	        } else {
	            // Compute decimal equivalent
	            decimalEquivalent = (double) numerator / denominator;
	            System.out.println("Decimal equivalent: " + decimalEquivalent);
	        }

	        scan.close(); // Close the scanner
	    }
	}



