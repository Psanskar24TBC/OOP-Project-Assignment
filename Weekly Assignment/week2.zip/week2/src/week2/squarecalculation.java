package week2;
import java.util.Scanner;

public class squarecalculation {
	

	
	    public static void main(String[] args) {
	        int sideLength, perimeter, area;
	        Scanner scan = new Scanner(System.in);

	        // Prompt the user for input
	        System.out.print("Enter the length of the square's side: ");
	        sideLength = scan.nextInt(); // Read user input

	        // Calculate perimeter and area
	        perimeter = 4 * sideLength; // Perimeter formula: 4 × side
	        area = sideLength * sideLength; // Area formula: side²

	        // Display the results
	        System.out.println("Perimeter of the square: " + perimeter);
	        System.out.println("Area of the square: " + area);

	        scan.close(); // Close the scanner
	    }
	}




