package week2;

public class StudentGrades {

    public static void main(String[] args) {
        // Print the top border
        System.out.println("///////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\");
        System.out.println("==\t     Student Points     \t==");
        System.out.println("\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\///////////////////");
        
        // Print the table headers
        System.out.println("\nName\t\tLab\tBonus\tTotal");
        System.out.println("----\t\t---\t-----\t-----");
        
        // Print the student names and points
        System.out.println("Joe\t\t43\t7\t" + (43 + 7));
        System.out.println("William\t\t50\t8\t" + (50 + 8));
        System.out.println("Mary Sue\t39\t10\t" + (39 + 10));
        System.out.println("Alice\t\t45\t5\t" + (45 + 5));
        System.out.println("Bob\t\t48\t6\t" + (48 + 6));
    }
}
