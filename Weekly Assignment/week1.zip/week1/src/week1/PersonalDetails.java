package week1;

public class PersonalDetails {
	
	    public static void main(String[] args) {
	        System.out.println("Name:Sanskar Paudel");
	        System.out.println("Address: Kathmandu, Nepal");
	        System.out.println("Age: 25");
	        System.out.println("Phone Number: +977-9800000000");
	    }
}



