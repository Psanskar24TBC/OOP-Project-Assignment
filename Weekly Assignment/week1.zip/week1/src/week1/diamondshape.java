package week1;

public class diamondshape {
	
	    public static void main(String[] args) {
	        System.out.println("   *   ");
	        System.out.println("  ***  ");
	        System.out.println(" ***** ");
	        System.out.println("*******");
	        System.out.println(" ***** ");
	        System.out.println("  ***  ");
	        System.out.println("   *   ");
	    }
}

/*
a = java version "23.0.2" 

b = Java SE (Standard Edition): Used for general purpose programming (desktop, web, backend).
	Java ME (Micro Edition): Used for embedded systems, mobile devices, and iot.
	
c = Windows
	MacOS
	Linux

d =  intellij IDEA
	 VS Code 

e = The main() function is the entry point of a Java application
	It allows the program to execute instructions.*/

