package week1;

public class Test
{
   //----------------------------------------------------
   //  Prints a statement.
   //----------------------------------------------------
   public static void main (String[] args)
   {
      System.out.println ("An emergency Broadcast");
   }

}
/*a = Error: Unable to load main class week1.Test in module week1
	Caused by: java.lang.NoClassDefFoundError: week1/Test (wrong name: week1/test)
	Java is case-sensitive. The filename must match the class name exactly.
	
b = No error cause Java treats string literals as-is, so this does not affect compilation.

c = Exception in thread "main" java.lang.Error: Unresolved compilation problems: 
	Syntax error, insert ")" to complete MethodInvocation
	Syntax error, insert ";" to complete BlockStatements
	An cannot be resolved to a variable
	emergency cannot be resolved to a type
	Syntax error, insert ";" to complete LocalVariableDeclarationStatement
	String literal is not properly closed by a double-quote
	String literal is not properly closed by a double-quote
	at week1/week1.Test.main(Test.java:10) 

	Java requires a matching pair of quotation marks.
	
d = Error: Main method not found in class week1.Test, please define the main method as:
   public static void main(String[] args)
   or a JavaFX application class must extend javafx.application.Application
   
   The JVM looks for public static void main(String[] args). Changing main breaks the entry point.
   
e = Exception in thread "main" java.lang.Error: Unresolved compilation problem: 
	The method bogus(String) is undefined for the type PrintStream
	at week1/week1.Test.main(Test.java:10) 
	
	bogus is not a recognized method of System.out.
	
	
f = Exception in thread "main" java.lang.Error: Unresolved compilation problem: 
	Syntax error, insert ";" to complete BlockStatements
	at week1/week1.Test.main(Test.java:10)
	
	Java statements must end with a semicolon.

g =  Exception in thread "main" java.lang.Error: Unresolved compilation problem: 
	Syntax error, insert "}" to complete ClassBody
	at week1/week1.Test.main(Test.java:11)

	Braces {} define code blocks The missing closing brace causes an error.*/

