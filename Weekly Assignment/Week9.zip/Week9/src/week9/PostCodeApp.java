package week9;

import java.util.ArrayList;
import java.util.Scanner;

class Person {
    private String firstName;
    private String lastName;
    private String postalCode;

    public Person(String firstName, String lastName, String postalCode) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.postalCode = postalCode;
    }

    public String toString() {
        return firstName + " " + lastName + " - " + postalCode;
    }
}

public class PostCodeApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Person> people = new ArrayList<>();

        System.out.println("Enter up to 25 entries (FirstName<TAB/SPACE>LastName<TAB/SPACE>PostalCode):");
        System.out.println("Type 'x' to stop.");

        while (people.size() < 25) {
            String line = scanner.nextLine();
            if (line.trim().equalsIgnoreCase("x")) break;

            String[] parts = line.trim().split("\\s+");

            // Ensure that there are exactly 3 parts (FirstName, LastName, PostalCode)
            if (parts.length != 3) {
                System.out.println("Invalid input. Please enter three values: FirstName LastName PostalCode.");
                continue;
            }

            String firstName = parts[0].trim();
            String lastName = parts[1].trim();
            String postalCode = parts[2].trim();

            // Check if any of the fields are empty
            if (firstName.isEmpty() || lastName.isEmpty() || postalCode.isEmpty()) {
                System.out.println("Invalid input. Fields cannot be empty.");
                continue;
            }

            people.add(new Person(firstName, lastName, postalCode));
        }

        System.out.println("\nList of entries:");
        for (Person p : people) {
            System.out.println(p);
        }
    }
}
