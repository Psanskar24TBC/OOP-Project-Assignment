package week9;
import java.util.Scanner;

//The Question class encapsulates a quiz question.
class Question {
 private String text;
 private String answer;

 // Constructor to initialize the question text and the answer.
 public Question(String text, String answer) {
     this.text = text;
     this.answer = answer;
 }

 // Checks if the provided response matches the correct answer.
 public boolean isCorrect(String response) {
     return response.trim().equalsIgnoreCase(answer.trim());
 }

 // Getter for the question's text.
 public String getText() {
     return text;
 }
 
 // Getter for the correct answer.
 public String getAnswer() {
     return answer;
 }
}

//The Quiz class manages up to 25 questions and tracks the quiz progress.
class Quiz {
 private Question[] questions;
 private int count;
 private int score;

 // Constructor initializes an array to hold 25 questions.
 public Quiz() {
     questions = new Question[25]; // Maximum 25 questions
     count = 0;
     score = 0;
 }

 // Adds a new Question to the quiz if there's space.
 public void add(Question q) {
     if (count < questions.length) {
         questions[count++] = q;
     } else {
         System.out.println("Quiz is full. Cannot add more questions.");
     }
 }

 // Presents each question, receives the user's answer, and tracks the score.
 public void giveQuiz() {
     Scanner scanner = new Scanner(System.in);

     for (int i = 0; i < count; i++) {
         System.out.println("Question " + (i + 1) + ": " + questions[i].getText());
         System.out.print("Your answer: ");
         String userAnswer = scanner.nextLine();
         
         if (questions[i].isCorrect(userAnswer)) {
             System.out.println("Correct!\n");
             score++;
         } else {
             System.out.println("Incorrect. The correct answer is: " + questions[i].getAnswer() + "\n");
         }
     }
     
     // Display the final results.
     System.out.println("Quiz complete!");
     System.out.println("You answered " + score + " out of " + count + " questions correctly.");
 }
}

//The QuizTime class populates the quiz, presents it to the user, and prints the results.
public class QuizTime {
 public static void main(String[] args) {
     Quiz quiz = new Quiz();
     
     // Populate the quiz with questions.
     quiz.add(new Question("What is the capital of France?", "Paris"));
     quiz.add(new Question("What is 2 + 2?", "4"));
     quiz.add(new Question("Who wrote the Song 'DUSHMAN HEREKO HEREI'?", "durgesh thapa"));
     
     // Present the quiz to the user.
     quiz.giveQuiz();
 }
}
