package week9;

import java.util.Scanner;

public class Histogram {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int[] ranges = new int[10];

        System.out.println("Enter integers (1-100). Type any letter (e.g., 'x') then press Enter to stop:");


        while (scanner.hasNextInt()) {
            int num = scanner.nextInt();
            if (num >= 1 && num <= 100) {
                ranges[(num - 1) / 10]++;
            } else {
                System.out.println("Number out of range.");
            }
        }

        for (int i = 0; i < ranges.length; i++) {
            int lower = i * 10 + 1;
            int upper = (i + 1) * 10;
            System.out.printf("%2d -%3d | ", lower, upper);
            for (int j = 0; j < ranges[i]; j++) {
                System.out.print("*");
            }
            System.out.println();
        }
    }
}
