package week9;

import java.util.Scanner;

class Account {
    private String name;
    private int accountNumber;
    private double balance;

    public Account(String name, int accountNumber, double initialDeposit) {
        this.name = name;
        this.accountNumber = accountNumber;
        this.balance = initialDeposit;
    }

    public int getAccountNumber() {
        return accountNumber;
    }

    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println("Deposited $" + amount + " successfully.");
        } else {
            System.out.println("Invalid deposit amount.");
        }
    }

    public void withdraw(double amount) {
        if (amount <= 0) {
            System.out.println("Withdrawal amount must be positive.");
        } else if (amount > balance) {
            System.out.println("Insufficient funds.");
        } else {
            balance -= amount;
            System.out.println("Withdrew $" + amount + " successfully.");
        }
    }

    public void applyInterest(double rate) {
        balance += balance * rate / 100;
    }

    public void display() {
        System.out.printf("Account #%d | Name: %s | Balance: $%.2f%n", accountNumber, name, balance);
    }
}

class Bank {
    private Account[] accounts = new Account[30];
    private int count = 0;

    public void createAccount(String name, double initialDeposit) {
        if (count >= 30) {
            System.out.println("Bank is full. Cannot create more accounts.");
            return;
        }

        int accountNumber = 1000 + count; // Assign unique account number
        accounts[count] = new Account(name, accountNumber, initialDeposit);
        System.out.println("Account created successfully! Account Number: " + accountNumber);
        count++;
    }

    public Account findAccount(int accNumber) {
        for (int i = 0; i < count; i++) {
            if (accounts[i].getAccountNumber() == accNumber) {
                return accounts[i];
            }
        }
        return null;
    }

    public void depositToAccount(int accNumber, double amount) {
        Account acc = findAccount(accNumber);
        if (acc != null) {
            acc.deposit(amount);
        } else {
            System.out.println("Account not found.");
        }
    }

    public void withdrawFromAccount(int accNumber, double amount) {
        Account acc = findAccount(accNumber);
        if (acc != null) {
            acc.withdraw(amount);
        } else {
            System.out.println("Account not found.");
        }
    }

    public void applyInterestToAll(double rate) {
        for (int i = 0; i < count; i++) {
            accounts[i].applyInterest(rate);
        }
        System.out.println("Interest of " + rate + "% applied to all accounts.");
    }

    public void displayAllAccounts() {
        System.out.println("\nAll Bank Accounts:");
        for (int i = 0; i < count; i++) {
            accounts[i].display();
        }
    }
}

public class LLBankAccounts {
    public static void main(String[] args) {
        Bank bank = new Bank();
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n--- L&L Bank Menu ---");
            System.out.println("1. Create Account");
            System.out.println("2. Deposit");
            System.out.println("3. Withdraw");
            System.out.println("4. Apply 3% Interest");
            System.out.println("5. Display All Accounts");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    scanner.nextLine(); // Clear buffer
                    System.out.print("Enter customer name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter initial deposit: ");
                    double deposit = scanner.nextDouble();
                    bank.createAccount(name, deposit);
                    break;

                case 2:
                    System.out.print("Enter account number: ");
                    int depAcc = scanner.nextInt();
                    System.out.print("Enter amount to deposit: ");
                    double depAmount = scanner.nextDouble();
                    bank.depositToAccount(depAcc, depAmount);
                    break;

                case 3:
                    System.out.print("Enter account number: ");
                    int withAcc = scanner.nextInt();
                    System.out.print("Enter amount to withdraw: ");
                    double withAmount = scanner.nextDouble();
                    bank.withdrawFromAccount(withAcc, withAmount);
                    break;

                case 4:
                    bank.applyInterestToAll(3);
                    break;

                case 5:
                    bank.displayAllAccounts();
                    break;

                case 6:
                    System.out.println("Thank you for using L&L Bank.");
                    break;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }

        } while (choice != 6);

        scanner.close();
    }
}

