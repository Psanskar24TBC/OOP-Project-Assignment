package week3;
import java.util.Random;
import java.util.Scanner;

public class PinEncryption {
	
	 public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        Random random = new Random();

	        System.out.print("Enter a 4-digit pin number to encrypt: ");
	        int pin = scanner.nextInt();

	        // Generate two random numbers
	        int random1 = 1000 + random.nextInt(64536);
	        int random2 = 1000 + random.nextInt(64536);

	        // Convert numbers to hexadecimal
	        String hexPin = Integer.toHexString(pin);
	        String hexRand1 = Integer.toHexString(random1);
	        String hexRand2 = Integer.toHexString(random2);

	        // Concatenate to form encrypted pin
	        String encryptedPin = hexRand1 + hexPin + hexRand2;

	        System.out.println("Your encrypted pin number is " + encryptedPin);

	        scanner.close();
	    }
	}



