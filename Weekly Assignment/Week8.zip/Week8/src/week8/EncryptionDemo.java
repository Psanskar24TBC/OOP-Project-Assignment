package week8;

//Encryptable interface
interface Encryptable {
 void encrypt();
 String getEncrypted();
}

//Secret class using Caesar cipher encryption
class Secret implements Encryptable {
 private String data;
 private String encryptedData;
 private int shift = 3; // Default shift for Caesar cipher

 public Secret(String data) {
     this.data = data;
     this.encryptedData = "";
 }

 @Override
 public void encrypt() {
     StringBuilder result = new StringBuilder();
     for (char c : data.toCharArray()) {
         result.append((char) (c + shift));
     }
     encryptedData = result.toString();
 }

 @Override
 public String getEncrypted() {
     return encryptedData;
 }
}

//Password class using a reverse string encryption method
class Password implements Encryptable {
 private String password;
 private String encryptedPassword;

 public Password(String password) {
     this.password = password;
     this.encryptedPassword = "";
 }

 @Override
 public void encrypt() {
     encryptedPassword = new StringBuilder(password).reverse().toString();
 }

 @Override
 public String getEncrypted() {
     return encryptedPassword;
 }
}

//Driver class to demonstrate polymorphism
public class EncryptionDemo {
 public static void main(String[] args) {
     Encryptable secret = new Secret("HelloWorld");
     secret.encrypt();
     System.out.println("Encrypted Secret: " + secret.getEncrypted());

     System.out.println();

     secret = new Password("MySecurePass");
     secret.encrypt();
     System.out.println("Encrypted Password: " + secret.getEncrypted());
 }
}


