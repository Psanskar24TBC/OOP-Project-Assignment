package week8;

//Base Employee class
class Employee {
 protected String name;
 protected double salary;
 
 public Employee(String name, double salary) {
     this.name = name;
     this.salary = salary;
 }
 
 public void displayInfo() {
     System.out.println("Employee: " + name + ", Salary: $" + salary);
 }
 
 public void vacationDays() {
     System.out.println(name + " has a standard vacation package.");
 }
}

//Manager subclass
class Manager extends Employee {
 public Manager(String name, double salary) {
     super(name, salary);
 }
 
 @Override
 public void vacationDays() {
     System.out.println(name + " gets 30 vacation days and a bonus vacation package.");
 }
}

//Developer subclass
class Developer extends Employee {
 public Developer(String name, double salary) {
     super(name, salary);
 }
 
 @Override
 public void vacationDays() {
     System.out.println(name + " gets 20 vacation days with a work-from-home option.");
 }
}

//Intern subclass
class Intern extends Employee {
 public Intern(String name, double salary) {
     super(name, salary);
 }
 
 @Override
 public void vacationDays() {
     System.out.println(name + " gets 10 vacation days, unpaid.");
 }
}

//Firm driver class
public class Firm {
 public static void main(String[] args) {
     Manager mgr = new Manager("Anil Limbu", 500000);
     Developer dev = new Developer("Alex Tamage", 300000);
     Intern intern = new Intern("Krsna ", 10000);
     
     mgr.displayInfo();
     mgr.vacationDays();
     
     System.out.println();
     
     dev.displayInfo();
     dev.vacationDays();
     
     System.out.println();
     
     intern.displayInfo();
     intern.vacationDays();
 }
}

