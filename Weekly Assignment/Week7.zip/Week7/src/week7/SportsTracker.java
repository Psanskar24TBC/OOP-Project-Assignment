package week7;

//Base class for player statistics
class PlayerStats {
 protected String playerName;
 protected int matchesPlayed;
 
 public PlayerStats(String playerName, int matchesPlayed) {
     this.playerName = playerName;
     this.matchesPlayed = matchesPlayed;
 }
 
 public void displayStats() {
     System.out.println("Player: " + playerName + ", Matches Played: " + matchesPlayed);
 }
}

//Football-specific statistics class
class FootballStats extends PlayerStats {
 private int goalsScored;
 
 public FootballStats(String playerName, int matchesPlayed, int goalsScored) {
     super(playerName, matchesPlayed);
     this.goalsScored = goalsScored;
 }
 
 public void displayFootballStats() {
     displayStats();
     System.out.println("Goals Scored: " + goalsScored);
 }
}

//Cricket-specific statistics class
class CricketStats extends PlayerStats {
 private int runsScored;
 private int wicketsTaken;
 
 public CricketStats(String playerName, int matchesPlayed, int runsScored, int wicketsTaken) {
     super(playerName, matchesPlayed);
     this.runsScored = runsScored;
     this.wicketsTaken = wicketsTaken;
 }
 
 public void displayCricketStats() {
     displayStats();
     System.out.println("Runs Scored: " + runsScored + ", Wickets Taken: " + wicketsTaken);
 }
}

//Driver class to test the functionality
public class SportsTracker {
 public static void main(String[] args) {
     FootballStats footballPlayer = new FootballStats("Lionel Messi", 800, 750);
     CricketStats cricketPlayer = new CricketStats("Virat Kohli", 500, 24000, 10);
     
     footballPlayer.displayFootballStats();
     System.out.println();
     cricketPlayer.displayCricketStats();
 }
}
