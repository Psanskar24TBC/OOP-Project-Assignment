package week7;

//Base class Employee
class Employee {
 protected String name;
 protected int id;
 
 public Employee(String name, int id) {
     this.name = name;
     this.id = id;
 }
 
 public void displayInfo() {
     System.out.println("Employee ID: " + id + ", Name: " + name);
 }
}

//Doctor class
class Doctor extends Employee {
 private String specialty;
 
 public Doctor(String name, int id, String specialty) {
     super(name, id);
     this.specialty = specialty;
 }
 
 public void diagnose() {
     System.out.println("Doctor " + name + " specializes in " + specialty + ".");
 }
}

//Nurse class
class Nurse extends Employee {
 private int numPatients;
 
 public Nurse(String name, int id, int numPatients) {
     super(name, id);
     this.numPatients = numPatients;
 }
 
 public void careForPatients() {
     System.out.println("Nurse " + name + " is taking care of " + numPatients + " patients.");
 }
}

//Receptionist class
class Receptionist extends Employee {
 public Receptionist(String name, int id) {
     super(name, id);
 }
 
 public void answerCalls() {
     System.out.println("Receptionist " + name + " is answering phone calls.");
 }
}

//Cleaner class
class Cleaner extends Employee {
 public Cleaner(String name, int id) {
     super(name, id);
 }
 
 public void sweep() {
     System.out.println("Cleaner " + name + " is sweeping the hospital floors.");
 }
}

//Driver class
public class Hospital {
 public static void main(String[] args) {
     Doctor doc = new Doctor("Ramesh", 101, "Cardiology");
     Nurse nurse = new Nurse("Kiran", 102, 5);
     Receptionist receptionist = new Receptionist("Alan", 103);
     Cleaner cleaner = new Cleaner("Dipesh", 104);

     doc.displayInfo();
     doc.diagnose();
     
     nurse.displayInfo();
     nurse.careForPatients();

     receptionist.displayInfo();
     receptionist.answerCalls();
     
     cleaner.displayInfo();
     cleaner.sweep();
 }
}
