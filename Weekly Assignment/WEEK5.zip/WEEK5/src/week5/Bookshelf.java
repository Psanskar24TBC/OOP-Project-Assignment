package week5;

class Book {
    private String title;
    private String author;
    private String publisher;
    private int copyrightDate;

    // Constructor
    public Book(String title, String author, String publisher, int copyrightDate) {
        this.title = title;
        this.author = author;
        this.publisher = publisher;
        this.copyrightDate = copyrightDate;
    }

    // Getters
    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public String getPublisher() {
        return publisher;
    }

    public int getCopyrightDate() {
        return copyrightDate;
    }

    // Setters
    public void setTitle(String title) {
        this.title = title;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public void setCopyrightDate(int copyrightDate) {
        this.copyrightDate = copyrightDate;
    }

    // toString method
    @Override
    public String toString() {
        return "Title: " + title + "\n" +
               "Author: " + author + "\n" +
               "Publisher: " + publisher + "\n" +
               "Copyright Date: " + copyrightDate + "\n";
    }
}

// Driver class
public class Bookshelf {
    public static void main(String[] args) {
        // Creating Book objects
        Book book1 = new Book("The Great Gatsby", "F. Scott Fitzgerald", "Scribner", 1925);
        Book book2 = new Book("1984", "George Orwell", "Secker & Warburg", 1949);
        Book book3 = new Book("Palpasa Café", "Narayan Wagle", "Nepalaya", 2005);
        Book book4 = new Book("Muna Madan", "Laxmi Prasad Devkota", "Sajha Prakashan", 1936);

        // Displaying book information
        System.out.println(book1);
        System.out.println(book2);
        System.out.println(book3);
        System.out.println(book4);

        // Updating book details
        book1.setTitle("The Greatest Gatsby");
        book2.setCopyrightDate(1950);
        book3.setTitle("Palpasa Café - Revised Edition");

        // Displaying updated information
        System.out.println("After updates:");
        System.out.println(book1);
        System.out.println(book2);
        System.out.println(book3);
        System.out.println(book4);
    }
}
