package week5;

class Bulb {
    private boolean isOn;

// Constructor
    public Bulb() {
        this.isOn = false; // Default state is off
    }

// Method to turn on the bulb
    public void turnOn() {
        isOn = true;
    }

// Method to turn off the bulb
    public void turnOff() {
        isOn = false;
    }

// Method to check if the bulb is on
    public boolean isOn() {
        return isOn;
    }
// toString method
    @Override
    public String toString() {
        return "Bulb is " + (isOn ? "ON" : "OFF");
    }
}

// Driver class
public class Lights {
    public static void main(String[] args) {
// Creating Bulb objects
        Bulb bulb1 = new Bulb();
        Bulb bulb2 = new Bulb();
        
// Turning on some bulbs
        bulb1.turnOn();
        
// Displaying bulb states
        System.out.println(bulb1);
        System.out.println(bulb2);
        
// Turning on the second bulb
        bulb2.turnOn();
        
// Displaying updated bulb states
        System.out.println("After turning on second bulb:");
        System.out.println(bulb1);
        System.out.println(bulb2);
    }
}

