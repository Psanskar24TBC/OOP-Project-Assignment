package week5;

class Sphere {
    private double diameter;

// Constructor
    public Sphere(double diameter) {
        this.diameter = diameter;
    }

// Getter for diameter
    public double getDiameter() {
        return diameter;
    }

// Setter for diameter
    public void setDiameter(double diameter) {
        this.diameter = diameter;
    }
// Method to calculate volume
    public double getVolume() {
        double radius = diameter / 2.0;
        return (4.0 / 3.0) * Math.PI * Math.pow(radius, 3);
    }

// Method to calculate surface area
    public double getSurfaceArea() {
        double radius = diameter / 2.0;
        return 4 * Math.PI * Math.pow(radius, 2);
    }

// toString method
    @Override
    public String toString() {
        return "Sphere with diameter " + diameter + ", volume " + getVolume() + ", and surface area " + getSurfaceArea();
    }
}

// Driver class
public class MultiSphere {
    public static void main(String[] args) {
// Creating Sphere objects
        Sphere sphere1 = new Sphere(10);
        Sphere sphere2 = new Sphere(15);

// Displaying information
        System.out.println(sphere1);
        System.out.println(sphere2);

// Modifying diameter
        sphere1.setDiameter(12);
        sphere2.setDiameter(18);

// Displaying updated information
        System.out.println("After updating diameters:");
        System.out.println(sphere1);
        System.out.println(sphere2);
    }
}

