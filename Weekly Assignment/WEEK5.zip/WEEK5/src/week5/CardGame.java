package week5;

import java.util.Random;

class Card {
    private String suit;
    private String faceValue;

    private static final String[] SUITS = {"Hearts", "Diamonds", "Clubs", "Spades"};
    private static final String[] FACE_VALUES = {"2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King", "Ace"};

// Constructor
    public Card(String suit, String faceValue) {
        this.suit = suit;
        this.faceValue = faceValue;
    }

// Getters
    public String getSuit() {
        return suit;
    }

    public String getFaceValue() {
        return faceValue;
    }

// toString method
    @Override
    public String toString() {
        return faceValue + " of " + suit;
    }

// Method to generate a random card
    public static Card getRandomCard() {
        Random rand = new Random();
        String suit = SUITS[rand.nextInt(SUITS.length)];
        String faceValue = FACE_VALUES[rand.nextInt(FACE_VALUES.length)];
        return new Card(suit, faceValue);
    }
}

// Driver class
public class CardGame {
    public static void main(String[] args) {
        System.out.println("Dealing five random cards:");
        for (int i = 0; i < 5; i++) {
            System.out.println(Card.getRandomCard());
        }
    }
}
