package week5;

class Account {
    private String name;
    private String accountNumber;
    private double balance;

    // Constructor with name, account number, and initial balance
    public Account(String name, String accountNumber, double balance) {
        this.name = name;
        this.accountNumber = accountNumber;
        this.balance = balance;
    }

    // Constructor with name and account number (default balance = 0)
    public Account(String name, String accountNumber) {
        this(name, accountNumber, 0.0);
    }

    // Getter methods
    public String getName() {
        return name;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public double getBalance() {
        return balance;
    }

    // Method to deposit money
    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
        }
    }

    // Method to withdraw money
    public boolean withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            return true;
        }
        return false;
    }

    // toString method
    @Override
    public String toString() {
        return "Account Holder: " + name + "\n" +
               "Account Number: " + accountNumber + "\n" +
               "Balance: $" + balance + "\n";
    }
}

// Driver class
public class Transactions {
    public static void main(String[] args) {
        // Creating accounts with and without initial balance
        Account account1 = new Account("John Cena", "123456", 500.0);
        Account account2 = new Account("Harry Kane", "789012");

        // Displaying account details
        System.out.println(account1);
        System.out.println(account2);

        // Performing transactions
        account2.deposit(300);
        account1.withdraw(200);

        // Displaying updated account details
        System.out.println("After transactions:");
        System.out.println(account1);
        System.out.println(account2);
    }
}
